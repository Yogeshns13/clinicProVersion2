// src/components/ViewAppointment.jsx
import React, { useState, useEffect } from 'react';
import { FiX, FiCalendar, FiUser, FiPhone, FiFileText, FiClock } from 'react-icons/fi';
import { getAppointmentList, cancelAppointment } from '../Api/Api.js';
import './ViewAppointment.css';
import { FaClinicMedical } from 'react-icons/fa';
import { getStoredClinicId, getStoredBranchId } from '../Utils/Cryptoutils.js';


// ────────────────────────────────────────────────
// Helper function to convert status code to string
// ────────────────────────────────────────────────
const getStatusString = (status) => {
  switch (status) {
    case 1:
      return 'scheduled';
    case 2:
      return 'confirmed';
    case 3:
      return 'inprogress';
    case 4:
      return 'completed';
    case 5:
      return 'cancelled';
    default:
      return 'unknown';
  }
};

// ────────────────────────────────────────────────
const ViewAppointment = ({ isOpen, onClose, appointment: passedAppointment, onRefresh }) => {
  const [appointment, setAppointment] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [cancelLoading, setCancelLoading] = useState(false);
  const [showCancelConfirm, setShowCancelConfirm] = useState(false);

  // ────────────────────────────────────────────────
  useEffect(() => {
    const fetchAppointmentDetails = async () => {
      // If appointment is passed as prop, use it directly
      if (passedAppointment) {
        setAppointment(passedAppointment);
        setLoading(false);
        return;
      }

      // Otherwise, fetch it (this handles the appointmentId prop case)
      if (!isOpen) return;

      try {
        setLoading(true);
        setError(null);

        const clinicId = await getStoredClinicId();
        const branchId = await getStoredBranchId();

        const data = await getAppointmentList(clinicId, {
          BranchID: branchId,
          AppointmentID: Number(passedAppointment?.id || 0),
        });

        if (data && data.length > 0) {
          setAppointment(data[0]);
        } else {
          setError({ message: 'Appointment not found' });
        }
      } catch (err) {
        console.error('fetchAppointmentDetails error:', err);
        setError({
          message: err.message || 'Failed to load appointment details',
        });
      } finally {
        setLoading(false);
      }
    };

    if (isOpen) {
      fetchAppointmentDetails();
      setShowCancelConfirm(false);
    }
  }, [passedAppointment, isOpen]);

  // ────────────────────────────────────────────────
  // Helper functions
  const formatDate = (dateString) => {
    if (!dateString) return '—';
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString('en-IN', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        weekday: 'long',
      });
    } catch {
      return dateString;
    }
  };

  const formatTime = (timeStr) => {
    if (!timeStr) return '—';

    // Parse HH:MM format
    const [hours, minutes] = timeStr.split(':').map(Number);

    // Convert to 12-hour format
    const period = hours >= 12 ? 'PM' : 'AM';
    const hour12 = hours % 12 || 12;

    return `${hour12}:${minutes.toString().padStart(2, '0')} ${period}`;
  };

  const getStatusClass = (status) => {
    const statusStr = getStatusString(status);
    if (statusStr === 'scheduled') return 'active';
    if (statusStr === 'confirmed') return 'active';
    if (statusStr === 'inprogress') return 'active';
    if (statusStr === 'completed') return 'completed';
    if (statusStr === 'cancelled') return 'inactive';
    return 'inactive';
  };

  const handleCancelClick = () => {
    setShowCancelConfirm(true);
  };

  const handleCancelAppointment = async () => {
    if (!appointment) return;

    setCancelLoading(true);
    try {
      await cancelAppointment(appointment.id);
      
      // Refresh the parent list
      if (onRefresh) {
        onRefresh();
      }
      
      // Close the modal
      onClose();
    } catch (err) {
      console.error('Failed to cancel appointment:', err);
      setError({ message: err.message || 'Failed to cancel appointment' });
    } finally {
      setCancelLoading(false);
      setShowCancelConfirm(false);
    }
  };

  const handleCloseCancelConfirm = () => {
    setShowCancelConfirm(false);
  };

  // ────────────────────────────────────────────────
  // Don't render if not open
  if (!isOpen) return null;

  // ────────────────────────────────────────────────
  return (
    <div className="appointment-modal-overlay">
      <div className="appointment-modal">
        {/* Header */}
        <div className="appointment-modal-header">
          <div className="appointment-header-content">
            <FiCalendar className="appointment-header-icon" size={24} />
            <h2>Appointment Details</h2>
          </div>
          <div className="clinicNameone">
             <FaClinicMedical size={18} style={{ verticalAlign: 'middle', margin: '6px', marginTop: '0px' }} />  
               {localStorage.getItem('clinicName') || '—'}
                  </div>
          <button onClick={onClose} className="appointment-modal-close">
            <FiX size={20} />
          </button>
        </div>

        {/* Body */}
        <div className="appointment-modal-body">
          {loading && (
            <div className="appointment-loading">
              <div className="appointment-spinner"></div>
              <p>Loading appointment details...</p>
            </div>
          )}

          {error && (
            <div className="appointment-error">
              <p>Error: {error.message || error}</p>
            </div>
          )}

          {!loading && !error && appointment && (
            <>
              {/* Patient Information */}
              {/* Patient & Doctor Information */}
<div className="appointment-details-section">
  <h3 className="appointment-section-title">
    <FiUser size={18} />
    Patient & Doctor Information
  </h3>
  <div className="appointment-details-grid">
    <div className="appointment-detail-item">
      <span className="appointment-detail-label">Patient Name</span>
      <span className="appointment-detail-value">{appointment.patientName || '—'}</span>
    </div>

    <div className="appointment-detail-item">
      <span className="appointment-detail-label">File Number</span>
      <span className="appointment-detail-value">{appointment.patientFileNo || '—'}</span>
    </div>

    <div className="appointment-detail-item">
      <span className="appointment-detail-label">Mobile</span>
      <span className="appointment-detail-value">{appointment.patientMobile || '—'}</span>
    </div>

    <div className="appointment-detail-item">
      <span className="appointment-detail-label">Doctor Name</span>
      <span className="appointment-detail-value">{appointment.doctorFullName || '—'}</span>
    </div>

    <div className="appointment-detail-item">
      <span className="appointment-detail-label">Doctor Code</span>
      <span className="appointment-detail-value">{appointment.doctorCode || '—'}</span>
    </div>
  </div>
</div>


{/* Appointment Details */}
<div className="appointment-details-section">
  <h3 className="appointment-section-title">
    <FiCalendar size={18} />
    Appointment Details
  </h3>
  <div className="appointment-details-grid">
    <div className="appointment-detail-item">
      <span className="appointment-detail-label">Date</span>
      <span className="appointment-detail-value">
        {formatDate(appointment.appointmentDate)}
      </span>
    </div>

    <div className="appointment-detail-item">
      <span className="appointment-detail-label">Time</span>
      <span className="appointment-detail-value">
        {formatTime(appointment.appointmentTime)}
      </span>
    </div>

    <div className="appointment-detail-item appointment-full-width">
      <span className="appointment-detail-label">Reason for Visit</span>
      <span className="appointment-detail-value">
        {appointment.reason || '—'}
      </span>
    </div>
  </div>
</div>


{/* Clinic & Record Information */}
<div className="appointment-details-section">
  <h3 className="appointment-section-title">
    <FiFileText size={18} />
    Clinic & Record Information
  </h3>
  <div className="appointment-details-grid">
    <div className="appointment-detail-item">
      <span className="appointment-detail-label">Clinic Name</span>
      <span className="appointment-detail-value">{appointment.clinicName || '—'}</span>
    </div>

    <div className="appointment-detail-item">
      <span className="appointment-detail-label">Branch Name</span>
      <span className="appointment-detail-value">{appointment.branchName || '—'}</span>
    </div>

    <div className="appointment-detail-item">
      <span className="appointment-detail-label">Date Created</span>
      <span className="appointment-detail-value">
        {formatDate(appointment.dateCreated)}
      </span>
    </div>

    <div className="appointment-detail-item">
      <span className="appointment-detail-label">Last Modified</span>
      <span className="appointment-detail-value">
        {formatDate(appointment.dateModified)}
      </span>
    </div>
  </div>
</div>

              {/* Cancel Confirmation */}
              {showCancelConfirm && (
                <div className="appointment-cancel-confirmation">
                  <p className="cancel-warning">
                    Are you sure you want to cancel this appointment? This action cannot be undone.
                  </p>
                  <div className="cancel-actions">
                    <button 
                      onClick={handleCloseCancelConfirm} 
                      className="cancel-no-btn"
                      disabled={cancelLoading}
                    >
                      No, Keep It
                    </button>
                    <button 
                      onClick={handleCancelAppointment} 
                      className="cancel-yes-btn"
                      disabled={cancelLoading}
                    >
                      {cancelLoading ? 'Cancelling...' : 'Yes, Cancel'}
                    </button>
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer */}
        <div className="appointment-modal-footer">
          {!showCancelConfirm && appointment && appointment.status === 1 && (
            <button 
              onClick={handleCancelClick} 
              className="appointment-cancel-appointment-btn"
            >
              Cancel Appointment
            </button>
          )}
          <button onClick={onClose} className="appointment-close-btn">
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default ViewAppointment;